/* Bar functionality */
#include "bar_ltsymbol.h"
//#include "bar_status.h"
#include "bar_tags.h"
#include "bar_wintitle.h"
#include "bar_status2d.h"
#include "bar_dwmblocks.h"
#include "bar_statuscmd.h"