static int click_statuscmd(Bar *bar, Arg *arg, BarClickArg *a);
static int click_statuscmd_es(Bar *bar, Arg *arg, BarClickArg *a);
static int click_statuscmd_text(Arg *arg, int rel_x, char *text);
static void copyvalidchars(char *text, char *rawtext);