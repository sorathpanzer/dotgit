static int width_wintitle(Bar *bar, BarWidthArg *a);
static int draw_wintitle(Bar *bar, BarDrawArg *a);
static int click_wintitle(Bar *bar, Arg *arg, BarClickArg *a);
