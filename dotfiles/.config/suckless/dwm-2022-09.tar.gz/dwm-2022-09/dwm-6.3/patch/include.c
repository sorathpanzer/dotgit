/* Bar functionality */
#include "bar_ltsymbol.c"
//#include "bar_status.c"
#include "bar_tags.c"
#include "bar_wintitle.c"
#include "bar_status2d.c"
#include "bar_dwmblocks.c"
#include "bar_statuscmd.c"