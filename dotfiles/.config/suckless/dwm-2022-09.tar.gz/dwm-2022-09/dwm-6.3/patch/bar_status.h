static int width_status(Bar *bar, BarWidthArg *a);
static int draw_status(Bar *bar, BarDrawArg *a);
static int click_status(Bar *bar, Arg *arg, BarClickArg *a);
