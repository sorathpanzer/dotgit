static int width_ltsymbol(Bar *bar, BarWidthArg *a);
static int draw_ltsymbol(Bar *bar, BarDrawArg *a);
static int click_ltsymbol(Bar *bar, Arg *arg, BarClickArg *a);
