static int width_status2d(Bar *bar, BarWidthArg *a);
static int width_status2d_es(Bar *bar, BarWidthArg *a);
static int draw_status2d(Bar *bar, BarDrawArg *a);
static int draw_status2d_es(Bar *bar, BarDrawArg *a);
static int drawstatusbar(int x, char *text);
static int status2dtextlength(char *stext);