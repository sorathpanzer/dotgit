static int getdwmblockspid();
static void sigdwmblocks(const Arg *arg);